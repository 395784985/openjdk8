FileChooserDemo demonstrates some of the capabilities of the 
JFileChooser object.  It brings up a window displaying several
configuration controls that allow you to play with the
JFileChooser options dynamically.
 
To run the FileChooserDemo demo:

  java -jar FileChooserDemo.jar

These instructions assume that this installation's version of the java
command is in your path.  If it isn't, then you should either
specify the complete path to the java command or update your
PATH environment variable as described in the installation
instructions for the Java(TM) SE Development Kit.
